COERbuoy1 model & benchmark
A realistic benchmark for Wave Enegery Converter controllers

The commands how to run python might differ between systems, and the ones presented here might not work on every machine. Please see https://www.python.org/ to find the correct commands for your system.

See https://github.com/SiHeTh/COERbuoyOne for further infromation.


Funding
This project was part-funded byScience Foundation Ireland (SFI) through MaREI, the SFI Research Centre for Energy, Climate, and Marine [Grant No: 12/RC/2302 P2], with supporting funding obtained from CorPower Ocean AB.
